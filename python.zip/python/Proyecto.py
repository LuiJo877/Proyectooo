"""
=============================================================
 REGRESION LINEAL - SALARIOS ING. SISTEMAS (REP. DOMINICANA)
=============================================================
"""

# ============================================================
# IMPORTACIONES
# ============================================================
import numpy as np
import pandas as pd
import os
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

os.system("")
os.makedirs("resultados", exist_ok=True)
np.random.seed(42)

ARCHIVO_HISTORIAL = "resultados/historial_predicciones.csv"


# ============================================================
# SISTEMA DE COLORES
# ============================================================
class C:
    RESET      = "\033[0m"
    NEGRITA    = "\033[1m"

    ROJO       = "\033[91m"
    VERDE      = "\033[92m"
    AMARILLO   = "\033[93m"
    AZUL       = "\033[94m"
    MAGENTA    = "\033[95m"
    CIAN       = "\033[96m"
    BLANCO     = "\033[97m"
    GRIS       = "\033[90m"

    BG_ROJO    = "\033[101m"
    BG_VERDE   = "\033[102m"
    BG_AMARILLO= "\033[103m"
    BG_AZUL    = "\033[104m"
    BG_MAGENTA = "\033[105m"
    BG_CIAN    = "\033[106m"


def c(texto, *codigos):
    return "".join(codigos) + str(texto) + C.RESET


# ============================================================
# DISEÑO
# ============================================================
ANCHO = 62


def limpiar():
    os.system("cls" if os.name == "nt" else "clear")


def banner():
    print()
    print(c("  ╔" + "═" * ANCHO + "╗", C.NEGRITA, C.CIAN))
    print(c("  ║" + " " * ANCHO + "║", C.NEGRITA, C.CIAN))
    print(c("  ║", C.NEGRITA, C.CIAN) +
          " " * 5 +
          c("▓▓▓", C.NEGRITA, C.MAGENTA) +
          c("  REGRESION LINEAL - SALARIOS  ", C.NEGRITA, C.AMARILLO) +
          c("▓▓▓", C.NEGRITA, C.MAGENTA) +
          " " * 5 +
          c("║", C.NEGRITA, C.CIAN))
    print(c("  ║", C.NEGRITA, C.CIAN) +
          " " * 12 +
          c("INGENIERIA EN SISTEMAS", C.NEGRITA, C.VERDE) +
          " " * 12 +
          c("║", C.NEGRITA, C.CIAN))
    print(c("  ║", C.NEGRITA, C.CIAN) +
          " " * 13 +
          c("Republica Dominicana - DOP", C.MAGENTA) +
          " " * 11 +
          c("║", C.NEGRITA, C.CIAN))
    print(c("  ║" + " " * ANCHO + "║", C.NEGRITA, C.CIAN))
    print(c("  ╚" + "═" * ANCHO + "╝", C.NEGRITA, C.CIAN))


def titulo(texto):
    print()
    print(c("  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓", C.NEGRITA, C.CIAN))
    print(c(f"  ▓  {texto}", C.NEGRITA, C.AMARILLO))
    print(c("  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓", C.NEGRITA, C.CIAN))


def subtitulo(texto):
    print()
    print(c(f"  ▶▶▶ {texto} ", C.NEGRITA, C.MAGENTA) + c("◄◄◄", C.NEGRITA, C.MAGENTA))


def fila(etiqueta, valor, color_valor=C.BLANCO, ancho_etq=24):
    etiqueta_formateada = f"{etiqueta:<{ancho_etq}}"
    print(f"    {c(etiqueta_formateada, C.BLANCO)} {c(str(valor), C.NEGRITA, color_valor)}")


def divisor(color=C.GRIS):
    print("    " + c("─" * 54, color))


def pausa():
    input("\n  " + c("Presiona ENTER para continuar...", C.GRIS))


def tarjeta_prediccion(indice, row):
    """Dibuja una tarjeta visual para una prediccion del historial."""
    # Clasificacion por salario
    if row["salario_mensual_dop"] >= 100000:
        color_sal = C.VERDE
        nivel = "ALTO"
    elif row["salario_mensual_dop"] >= 75000:
        color_sal = C.AMARILLO
        nivel = "MEDIO"
    else:
        color_sal = C.CIAN
        nivel = "INICIAL"

    print()
    print(c("  ┌" + "─" * 58 + "┐", C.GRIS))

    encabezado = f"  PREDICCION #{indice:<3}"
    etiqueta_nivel = f"[ {nivel} ]  "
    espacios = 58 - len(encabezado) - len(etiqueta_nivel)

    print(c("  │", C.GRIS) +
          c(encabezado, C.NEGRITA, C.CIAN) +
          " " * espacios +
          c(etiqueta_nivel, C.NEGRITA, color_sal) +
          c("│", C.GRIS))

    print(c("  ├" + "─" * 58 + "┤", C.GRIS))

    linea_fecha = f"  Fecha:  {row['fecha']}"
    print(c("  │", C.GRIS) +
          c(linea_fecha + " " * (58 - len(linea_fecha)), C.GRIS) +
          c("│", C.GRIS))
    print(c("  │" + " " * 58 + "│", C.GRIS))

    lineas_datos = [
        ("Experiencia",     f"{int(row['experiencia'])} anios"),
        ("Certificaciones", f"{int(row['certificaciones'])}"),
        ("Promedio",        f"{row['promedio']:.1f}"),
        ("Horas/semana",    f"{int(row['horas_estudio'])}"),
        ("Nivel de ingles", f"{int(row['ingles'])}/5"),
    ]

    for etq, val in lineas_datos:
        contenido = f"    {etq:<18}:  {val}"
        relleno = " " * (58 - len(contenido))
        print(c("  │", C.GRIS) +
              c(contenido, C.BLANCO) +
              relleno +
              c("│", C.GRIS))

    print(c("  │" + " " * 58 + "│", C.GRIS))
    print(c("  ├" + "─" * 58 + "┤", C.GRIS))

    cont_m = f"    MENSUAL:   RD$ {row['salario_mensual_dop']:>12,.2f}"
    cont_a = f"    ANUAL:     RD$ {row['salario_anual_dop']:>12,.2f}"

    print(c("  │", C.GRIS) +
          c(cont_m, C.NEGRITA, C.BG_VERDE) +
          " " * (58 - len(cont_m)) +
          c("│", C.GRIS))

    print(c("  │", C.GRIS) +
          c(cont_a, C.NEGRITA, C.BG_MAGENTA) +
          " " * (58 - len(cont_a)) +
          c("│", C.GRIS))

    print(c("  └" + "─" * 58 + "┘", C.GRIS))


# ============================================================
# 1. GENERAR DATA SET
# ============================================================
def generar_dataset(n=300):
    experiencia     = np.random.randint(0, 11, n)
    certificaciones = np.random.randint(0, 8, n)
    promedio        = np.random.uniform(70, 100, n)
    horas_estudio   = np.random.randint(2, 25, n)
    ingles          = np.random.randint(1, 6, n)

    salario = (
        55000
        + experiencia * 3500
        + certificaciones * 2800
        + (promedio - 70) * 400
        + horas_estudio * 500
        + ingles * 4500
        + np.random.normal(0, 4000, n)
    )

    df = pd.DataFrame({
        "experiencia": experiencia,
        "certificaciones": certificaciones,
        "promedio": promedio,
        "horas_estudio": horas_estudio,
        "ingles": ingles,
        "salario_dop": salario
    })
    df.to_csv("dataset_ing_sistemas_rd.csv", index=False)
    return df


# ============================================================
# 2. ENTRENAR MODELO
# ============================================================
def entrenar_modelo(df):
    X = df[["experiencia", "certificaciones", "promedio",
            "horas_estudio", "ingles"]]
    y = df["salario_dop"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    modelo = LinearRegression()
    modelo.fit(X_train, y_train)
    y_pred = modelo.predict(X_test)

    metricas = {
        "r2":   r2_score(y_test, y_pred),
        "rmse": np.sqrt(mean_squared_error(y_test, y_pred)),
        "mae":  mean_absolute_error(y_test, y_pred),
        "cv":   cross_val_score(modelo, X, y, cv=5, scoring="r2").mean()
    }
    return modelo, metricas, X.columns.tolist()


# ============================================================
# 3. HISTORIAL - GUARDAR PREDICCION
# ============================================================
def guardar_prediccion(datos, salario_mensual):
    registro = {
        "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "experiencia": datos["experiencia"],
        "certificaciones": datos["certificaciones"],
        "promedio": datos["promedio"],
        "horas_estudio": datos["horas_estudio"],
        "ingles": datos["ingles"],
        "salario_mensual_dop": round(salario_mensual, 2),
        "salario_anual_dop": round(salario_mensual * 12, 2)
    }

    df_nuevo = pd.DataFrame([registro])

    if os.path.exists(ARCHIVO_HISTORIAL):
        df_nuevo.to_csv(ARCHIVO_HISTORIAL, mode="a", header=False, index=False)
    else:
        df_nuevo.to_csv(ARCHIVO_HISTORIAL, index=False)


def cargar_historial():
    if os.path.exists(ARCHIVO_HISTORIAL):
        return pd.read_csv(ARCHIVO_HISTORIAL)
    return pd.DataFrame()


# ============================================================
# 4. MOSTRAR RESUMEN
# ============================================================
def mostrar_resumen(df, modelo, metricas, columnas):
    limpiar()
    banner()
    titulo("RESUMEN DEL MODELO")

    subtitulo("Datos utilizados")
    fila("Registros:", f"{len(df)}", C.CIAN)
    fila("Variables:", f"{len(columnas)}", C.CIAN)
    fila("Salario promedio:", f"RD$ {df['salario_dop'].mean():,.0f} / mes", C.MAGENTA)

    subtitulo("Precision del modelo")
    divisor(C.VERDE)
    fila("R2:", f"{metricas['r2']:.2%}", C.VERDE)
    fila("RMSE:", f"RD$ {metricas['rmse']:,.0f}", C.VERDE)
    fila("MAE:", f"RD$ {metricas['mae']:,.0f}", C.VERDE)
    fila("CV R2:", f"{metricas['cv']:.2%}", C.VERDE)

    subtitulo("Impacto de cada variable en el salario")
    print(f"    {c('Variable', C.NEGRITA, C.BLANCO):<28}"
          f"{c('Aporte por unidad', C.NEGRITA, C.BLANCO)}")
    divisor(C.AMARILLO)

    pares = sorted(zip(columnas, modelo.coef_),
                   key=lambda x: abs(x[1]), reverse=True)

    for var, coef in pares:
        if abs(coef) >= 3000:
            col, marca = C.VERDE, "◆"
        elif abs(coef) >= 1000:
            col, marca = C.AMARILLO, "◇"
        else:
            col, marca = C.BLANCO, "·"
        print(c(f"    {marca} {var:<16}  +RD$ {coef:>10,.0f}", col))

    print()
    fila("Salario base:", f"RD$ {modelo.intercept_:,.0f}", C.CIAN)
    pausa()


# ============================================================
# 5. PREDICCION
# ============================================================
def predecir(modelo):
    limpiar()
    banner()
    titulo("PREDICCION DE SALARIO")

    print("    " + c("Completa los datos del candidato:", C.GRIS))
    print()

    try:
        experiencia     = float(input("    " + c("Anios de experiencia (0-10):", C.NEGRITA, C.CIAN) + "     "))
        certificaciones = float(input("    " + c("Certificaciones (0-7):", C.NEGRITA, C.CIAN) + "           "))
        promedio        = float(input("    " + c("Promedio academico (70-100):", C.NEGRITA, C.CIAN) + "     "))
        horas_estudio   = float(input("    " + c("Horas de estudio/semana (2-24):", C.NEGRITA, C.CIAN) + "  "))
        ingles          = float(input("    " + c("Nivel de ingles (1-5):", C.NEGRITA, C.CIAN) + "           "))

        datos = {
            "experiencia": experiencia,
            "certificaciones": certificaciones,
            "promedio": promedio,
            "horas_estudio": horas_estudio,
            "ingles": ingles
        }

        nuevo = pd.DataFrame({k: [v] for k, v in datos.items()})
        pred = modelo.predict(nuevo)[0]

        print()
        print(c("  ╔" + "═" * 58 + "╗", C.NEGRITA, C.VERDE))
        print(c("  ║", C.NEGRITA, C.VERDE) + " " * 20 +
              c("SALARIO ESTIMADO", C.NEGRITA, C.BG_VERDE) + " " * 20 +
              c("║", C.NEGRITA, C.VERDE))
        print(c("  ╠" + "═" * 58 + "╣", C.NEGRITA, C.VERDE))
        print(c("  ║", C.NEGRITA, C.VERDE) +
              c(f"      Mensual:   RD$ {pred:>12,.2f}      ", C.NEGRITA, C.AMARILLO) +
              c("║", C.NEGRITA, C.VERDE))
        print(c("  ║", C.NEGRITA, C.VERDE) +
              c(f"      Anual:     RD$ {pred * 12:>12,.2f}      ", C.NEGRITA, C.MAGENTA) +
              c("║", C.NEGRITA, C.VERDE))
        print(c("  ╚" + "═" * 58 + "╝", C.NEGRITA, C.VERDE))

        guardar_prediccion(datos, pred)
        print("\n    " + c("[ OK ] Prediccion guardada en el historial.",
                           C.NEGRITA, C.VERDE))

    except ValueError:
        print("\n    " + c("Error: ingresa valores numericos validos.",
                           C.NEGRITA, C.ROJO))

    pausa()


# ============================================================
# 6. VER HISTORIAL
# ============================================================
def ver_historial():
    limpiar()
    banner()
    titulo("HISTORIAL DE PREDICCIONES")

    df = cargar_historial()

    if df.empty:
        print()
        print(c("  ╔" + "═" * 58 + "╗", C.NEGRITA, C.AMARILLO))
        print(c("  ║" + " " * 58 + "║", C.NEGRITA, C.AMARILLO))
        print(c("  ║", C.NEGRITA, C.AMARILLO) + " " * 8 +
              c("NO HAY PREDICCIONES REGISTRADAS", C.NEGRITA, C.BG_AMARILLO) +
              " " * 8 + c("║", C.NEGRITA, C.AMARILLO))
        print(c("  ║" + " " * 58 + "║", C.NEGRITA, C.AMARILLO))
        print(c("  ╚" + "═" * 58 + "╝", C.NEGRITA, C.AMARILLO))
        print()
        print("    " + c("Usa la opcion [2] para predecir tu primer salario.", C.GRIS))
        pausa()
        return

    # --- Panel de estadisticas ---
    print()
    print(c("  ╔" + "═" * 58 + "╗", C.NEGRITA, C.MAGENTA))
    print(c("  ║", C.NEGRITA, C.MAGENTA) + " " * 16 +
          c("ESTADISTICAS GENERALES", C.NEGRITA, C.BG_MAGENTA) +
          " " * 16 + c("║", C.NEGRITA, C.MAGENTA))
    print(c("  ╠" + "═" * 58 + "╣", C.NEGRITA, C.MAGENTA))

    cont = f"    Total de predicciones:     {len(df)}"
    print(c("  ║", C.NEGRITA, C.MAGENTA) +
          c(cont, C.NEGRITA, C.CIAN) + " " * (58 - len(cont)) +
          c("║", C.NEGRITA, C.MAGENTA))

    print(c("  ╟" + "─" * 58 + "╢", C.GRIS))

    prom = df['salario_mensual_dop'].mean()
    cont = f"    Salario promedio:          RD$ {prom:>12,.2f}"
    print(c("  ║", C.NEGRITA, C.MAGENTA) +
          c(cont, C.NEGRITA, C.AMARILLO) + " " * (58 - len(cont)) +
          c("║", C.NEGRITA, C.MAGENTA))

    minimo = df['salario_mensual_dop'].min()
    cont = f"    Salario minimo:            RD$ {minimo:>12,.2f}"
    print(c("  ║", C.NEGRITA, C.MAGENTA) +
          c(cont, C.NEGRITA, C.CIAN) + " " * (58 - len(cont)) +
          c("║", C.NEGRITA, C.MAGENTA))

    maximo = df['salario_mensual_dop'].max()
    cont = f"    Salario maximo:            RD$ {maximo:>12,.2f}"
    print(c("  ║", C.NEGRITA, C.MAGENTA) +
          c(cont, C.NEGRITA, C.VERDE) + " " * (58 - len(cont)) +
          c("║", C.NEGRITA, C.MAGENTA))

    print(c("  ╚" + "═" * 58 + "╝", C.NEGRITA, C.MAGENTA))

    # --- Submenu ---
    while True:
        print()
        print(c("  ╔" + "═" * 58 + "╗", C.NEGRITA, C.CIAN))
        print(c("  ║", C.NEGRITA, C.CIAN) + " " * 22 +
              c("OPCIONES", C.NEGRITA, C.BG_CIAN) +
              " " * 22 + c("║", C.NEGRITA, C.CIAN))
        print(c("  ╠" + "═" * 58 + "╣", C.NEGRITA, C.CIAN))

        opciones = [
            ("A", "Ver todas las predicciones", C.AMARILLO),
            ("B", "Ver las ultimas 5 predicciones", C.AMARILLO),
            ("C", "Buscar por rango de salario", C.AMARILLO),
            ("D", "Eliminar historial completo", C.ROJO),
            ("E", "Volver al menu principal", C.GRIS),
        ]
        for letra, texto, col in opciones:
            cont = f"    [{letra}]   {texto}"
            print(c("  ║", C.NEGRITA, C.CIAN) +
                  c(cont, C.NEGRITA, col) + " " * (58 - len(cont)) +
                  c("║", C.NEGRITA, C.CIAN))

        print(c("  ╚" + "═" * 58 + "╝", C.NEGRITA, C.CIAN))

        op = input("\n  " + c("Elige una opcion (A-E): ",
                              C.NEGRITA, C.AMARILLO)).strip().upper()

        if op == "A":
            mostrar_todas(df)
        elif op == "B":
            mostrar_ultimas(df)
        elif op == "C":
            buscar_rango(df)
        elif op == "D":
            eliminar_historial()
            return
        elif op == "E":
            return
        else:
            print("\n    " + c("Opcion invalida.", C.NEGRITA, C.ROJO))
            pausa()
            limpiar()
            banner()
            titulo("HISTORIAL DE PREDICCIONES")
            print()
            print(c("  ╔" + "═" * 58 + "╗", C.NEGRITA, C.MAGENTA))
            print(c("  ║", C.NEGRITA, C.MAGENTA) + " " * 16 +
                  c("ESTADISTICAS GENERALES", C.NEGRITA, C.BG_MAGENTA) +
                  " " * 16 + c("║", C.NEGRITA, C.MAGENTA))
            print(c("  ╠" + "═" * 58 + "╣", C.NEGRITA, C.MAGENTA))
            cont = f"    Total de predicciones:     {len(df)}"
            print(c("  ║", C.NEGRITA, C.MAGENTA) +
                  c(cont, C.NEGRITA, C.CIAN) + " " * (58 - len(cont)) +
                  c("║", C.NEGRITA, C.MAGENTA))
            print(c("  ╟" + "─" * 58 + "╢", C.GRIS))
            cont = f"    Salario promedio:          RD$ {prom:>12,.2f}"
            print(c("  ║", C.NEGRITA, C.MAGENTA) +
                  c(cont, C.NEGRITA, C.AMARILLO) + " " * (58 - len(cont)) +
                  c("║", C.NEGRITA, C.MAGENTA))
            cont = f"    Salario minimo:            RD$ {minimo:>12,.2f}"
            print(c("  ║", C.NEGRITA, C.MAGENTA) +
                  c(cont, C.NEGRITA, C.CIAN) + " " * (58 - len(cont)) +
                  c("║", C.NEGRITA, C.MAGENTA))
            cont = f"    Salario maximo:            RD$ {maximo:>12,.2f}"
            print(c("  ║", C.NEGRITA, C.MAGENTA) +
                  c(cont, C.NEGRITA, C.VERDE) + " " * (58 - len(cont)) +
                  c("║", C.NEGRITA, C.MAGENTA))
            print(c("  ╚" + "═" * 58 + "╝", C.NEGRITA, C.MAGENTA))


def mostrar_todas(df):
    limpiar()
    banner()
    titulo(f"TODAS LAS PREDICCIONES ({len(df)})")

    df_ordenado = df.iloc[::-1].reset_index(drop=True)

    for i, row in df_ordenado.iterrows():
        numero = len(df_ordenado) - i
        tarjeta_prediccion(numero, row)

    print()
    print(c(f"  ── Fin del historial ── Total: {len(df)} predicciones ──",
            C.NEGRITA, C.CIAN))
    pausa()


def mostrar_ultimas(df):
    limpiar()
    banner()
    titulo("ULTIMAS 5 PREDICCIONES")

    ultimas = df.tail(5).iloc[::-1].reset_index(drop=True)

    for i, row in ultimas.iterrows():
        numero = len(df) - i
        tarjeta_prediccion(numero, row)

    print()
    print(c("  ── Fin de las ultimas 5 predicciones ──", C.NEGRITA, C.CIAN))
    pausa()


def buscar_rango(df):
    limpiar()
    banner()
    titulo("BUSCAR POR RANGO DE SALARIO")

    try:
        minimo = float(input("    " + c("Salario minimo (DOP):",
                                        C.NEGRITA, C.CIAN) + " "))
        maximo = float(input("    " + c("Salario maximo (DOP):",
                                        C.NEGRITA, C.CIAN) + " "))

        filtrado = df[(df["salario_mensual_dop"] >= minimo) &
                      (df["salario_mensual_dop"] <= maximo)]

        if filtrado.empty:
            print()
            print(c("  ╔" + "═" * 58 + "╗", C.NEGRITA, C.AMARILLO))
            print(c("  ║", C.NEGRITA, C.AMARILLO) + " " * 8 +
                  c("SIN RESULTADOS EN ESE RANGO", C.NEGRITA, C.BG_AMARILLO) +
                  " " * 8 + c("║", C.NEGRITA, C.AMARILLO))
            print(c("  ╚" + "═" * 58 + "╝", C.NEGRITA, C.AMARILLO))
        else:
            print()
            print(c(f"  Encontradas {len(filtrado)} predicciones en el rango",
                    C.NEGRITA, C.VERDE))
            print(c(f"  RD$ {minimo:,.2f}  -  RD$ {maximo:,.2f}",
                    C.NEGRITA, C.CIAN))

            df_ordenado = filtrado.iloc[::-1].reset_index(drop=True)
            for i, row in df_ordenado.iterrows():
                tarjeta_prediccion(i + 1, row)

    except ValueError:
        print("\n    " + c("Error: ingresa valores numericos validos.",
                           C.NEGRITA, C.ROJO))

    pausa()


def eliminar_historial():
    limpiar()
    banner()
    titulo("ELIMINAR HISTORIAL")

    print()
    print(c("  ╔" + "═" * 58 + "╗", C.NEGRITA, C.ROJO))
    print(c("  ║" + " " * 58 + "║", C.NEGRITA, C.ROJO))
    print(c("  ║", C.NEGRITA, C.ROJO) + " " * 6 +
          c("ADVERTENCIA: ACCION IRREVERSIBLE", C.NEGRITA, C.BG_ROJO) +
          " " * 6 + c("║", C.NEGRITA, C.ROJO))
    print(c("  ║" + " " * 58 + "║", C.NEGRITA, C.ROJO))
    print(c("  ╠" + "═" * 58 + "╣", C.NEGRITA, C.ROJO))
    print(c("  ║", C.NEGRITA, C.ROJO) + " " * 58 + c("║", C.NEGRITA, C.ROJO))
    cont = "    Se borraran TODAS las predicciones guardadas."
    print(c("  ║", C.NEGRITA, C.ROJO) +
          c(cont, C.NEGRITA, C.AMARILLO) + " " * (58 - len(cont)) +
          c("║", C.NEGRITA, C.ROJO))
    print(c("  ║", C.NEGRITA, C.ROJO) + " " * 58 + c("║", C.NEGRITA, C.ROJO))
    print(c("  ╚" + "═" * 58 + "╝", C.NEGRITA, C.ROJO))

    confirmar = input("\n  " + c("Estas seguro? (s/n): ",
                                 C.NEGRITA, C.AMARILLO)).strip().lower()

    if confirmar == "s":
        if os.path.exists(ARCHIVO_HISTORIAL):
            os.remove(ARCHIVO_HISTORIAL)
            print()
            print(c("  ╔" + "═" * 58 + "╗", C.NEGRITA, C.VERDE))
            print(c("  ║", C.NEGRITA, C.VERDE) + " " * 12 +
                  c("HISTORIAL ELIMINADO CORRECTAMENTE", C.NEGRITA, C.BG_VERDE) +
                  " " * 12 + c("║", C.NEGRITA, C.VERDE))
            print(c("  ╚" + "═" * 58 + "╝", C.NEGRITA, C.VERDE))
        else:
            print("\n    " + c("No hay historial que eliminar.", C.AMARILLO))
    else:
        print("\n    " + c("Operacion cancelada.", C.GRIS))

    pausa()


# ============================================================
# 7. VER DATA SET
# ============================================================
def ver_dataset(df):
    limpiar()
    banner()
    titulo("VISTA DEL DATA SET")

    print("    " + c("Primeras 10 filas:", C.GRIS))
    print()
    print(c("    " + df.head(10).to_string(index=False).replace("\n", "\n    "), C.BLANCO))
    print()
    fila("Total registros:", f"{len(df)}", C.CIAN)
    fila("Columnas:", f"{len(df.columns)}", C.CIAN)
    pausa()


# ============================================================
# 8. INFORMACION DEL PROYECTO
# ============================================================
def info_proyecto():
    limpiar()
    banner()
    titulo("INFORMACION DEL PROYECTO")

    subtitulo("Descripcion")
    print("    " + c("Modelo de regresion lineal que predice el salario", C.BLANCO))
    print("    " + c("mensual de un egresado de Ingenieria en Sistemas en", C.BLANCO))
    print("    " + c("Republica Dominicana, segun sus caracteristicas.", C.BLANCO))

    subtitulo("Variables del modelo")
    fila("1. Experiencia:", "anios trabajados (0-10)", C.CIAN)
    fila("2. Certificaciones:", "cantidad obtenidas (0-7)", C.CIAN)
    fila("3. Promedio:", "calificacion academica (70-100)", C.CIAN)
    fila("4. Horas de estudio:", "por semana (2-24)", C.CIAN)
    fila("5. Ingles:", "nivel (1-5)", C.CIAN)

    subtitulo("Tecnologias usadas")
    fila("Lenguaje:", "Python", C.VERDE)
    fila("Librerias:", "pandas, numpy, scikit-learn", C.VERDE)
    fila("Modelo:", "LinearRegression", C.VERDE)

    subtitulo("Archivos generados")
    fila("Dataset:", "dataset_ing_sistemas_rd.csv", C.AMARILLO)
    fila("Historial:", ARCHIVO_HISTORIAL, C.AMARILLO)

    pausa()


# ============================================================
# 9. MENU PRINCIPAL
# ============================================================
def menu():
    opciones = [
        ("1", "Ver resumen del modelo", C.AMARILLO),
        ("2", "Predecir salario", C.AMARILLO),
        ("3", "Ver historial de predicciones", C.VERDE),
        ("4", "Ver data set", C.AMARILLO),
        ("5", "Informacion del proyecto", C.AMARILLO),
        ("6", "Salir", C.ROJO),
    ]

    print()
    print(c("  ╔" + "═" * ANCHO + "╗", C.NEGRITA, C.MAGENTA))
    print(c("  ║", C.NEGRITA, C.MAGENTA) +
          " " * 22 +
          c("MENU PRINCIPAL", C.NEGRITA, C.BG_MAGENTA) +
          " " * 23 +
          c("║", C.NEGRITA, C.MAGENTA))
    print(c("  ╠" + "═" * ANCHO + "╣", C.NEGRITA, C.MAGENTA))
    print(c("  ║" + " " * ANCHO + "║", C.NEGRITA, C.MAGENTA))

    for num, texto, color_op in opciones:
        contenido = f"    [{num}]  {texto}"
        relleno = " " * (ANCHO - len(contenido))
        print(c("  ║", C.NEGRITA, C.MAGENTA) +
              c(contenido, C.NEGRITA, color_op) +
              relleno +
              c("║", C.NEGRITA, C.MAGENTA))

    print(c("  ║" + " " * ANCHO + "║", C.NEGRITA, C.MAGENTA))
    print(c("  ╚" + "═" * ANCHO + "╝", C.NEGRITA, C.MAGENTA))

    return input("\n  " + c("Elige una opcion (1-6): ", C.NEGRITA, C.CIAN)).strip()


# ============================================================
# 10. PROGRAMA PRINCIPAL
# ============================================================
def main():
    limpiar()
    banner()

    print()
    print("  " + c("[*] Generando datos...", C.GRIS) + "   " + c("[ OK ]", C.NEGRITA, C.VERDE))
    df = generar_dataset(300)

    print("  " + c("[*] Entrenando modelo...", C.GRIS) + " " + c("[ OK ]", C.NEGRITA, C.VERDE))
    modelo, metricas, columnas = entrenar_modelo(df)

    pausa()

    while True:
        limpiar()
        banner()
        opcion = menu()

        if opcion == "1":
            mostrar_resumen(df, modelo, metricas, columnas)
        elif opcion == "2":
            predecir(modelo)
        elif opcion == "3":
            ver_historial()
        elif opcion == "4":
            ver_dataset(df)
        elif opcion == "5":
            info_proyecto()
        elif opcion == "6":
            limpiar()
            banner()
            print()
            print(c("  ╔" + "═" * ANCHO + "╗", C.NEGRITA, C.MAGENTA))
            print(c("  ║" + " " * ANCHO + "║", C.NEGRITA, C.MAGENTA))
            print(c("  ║", C.NEGRITA, C.MAGENTA) +
                  " " * 15 +
                  c("GRACIAS POR USAR EL SISTEMA", C.NEGRITA, C.BG_MAGENTA) +
                  " " * 15 +
                  c("║", C.NEGRITA, C.MAGENTA))
            print(c("  ║" + " " * ANCHO + "║", C.NEGRITA, C.MAGENTA))
            print(c("  ╚" + "═" * ANCHO + "╝", C.NEGRITA, C.MAGENTA))
            print()
            break
        else:
            print("\n  " + c("Opcion invalida. Intenta de nuevo.", C.NEGRITA, C.ROJO))
            pausa()


# ============================================================
# EJECUCION
# ============================================================
if __name__ == "__main__":
    main()